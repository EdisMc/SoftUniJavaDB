package softuni.exam.models.entity;

import softuni.exam.models.entity.enums.ApartmentType;

import javax.persistence.*;
import javax.validation.constraints.Min;

@Entity
@Table(name = "apartments")
public class Apartment extends BaseEntity {

    @Column(name = "apartment_type", nullable = false)
    @Enumerated(EnumType.STRING)
    private ApartmentType apartment_type;

    @Column(name = "area")
    @Min(40)
    private double area;

    @ManyToOne
    @JoinColumn(name = "town_id")
    private Town town;

    public Apartment() {
    }

    public Apartment(ApartmentType apartment_type, double area, Town town) {
        this.apartment_type = apartment_type;
        this.area = area;
        this.town = town;
    }

    public ApartmentType getApartment_type() {
        return apartment_type;
    }

    public void setApartment_type(ApartmentType apartment_type) {
        this.apartment_type = apartment_type;
    }

    public double getArea() {
        return area;
    }

    public void setArea(double area) {
        this.area = area;
    }

    public Town getTown() {
        return town;
    }

    public void setTown(Town town) {
        this.town = town;
    }

}
