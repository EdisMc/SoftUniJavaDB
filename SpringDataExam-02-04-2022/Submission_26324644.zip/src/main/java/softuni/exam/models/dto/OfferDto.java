package softuni.exam.models.dto;

public class OfferDto {
}
