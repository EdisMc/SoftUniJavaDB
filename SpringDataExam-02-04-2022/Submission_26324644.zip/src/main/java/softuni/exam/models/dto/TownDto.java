package softuni.exam.models.dto;

import javax.validation.constraints.Positive;
import javax.validation.constraints.Size;

public class TownDto {

    @Size(min = 2)
    private String townName;

    @Positive
    private int population;

    public TownDto() {
    }

    public TownDto(String name, int population) {
        this.townName = name;
        this.population = population;
    }

    public String getName() {
        return townName;
    }

    public int getPopulation() {
        return population;
    }
}
