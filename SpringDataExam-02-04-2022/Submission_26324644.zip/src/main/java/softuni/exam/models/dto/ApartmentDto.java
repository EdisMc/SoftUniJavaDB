package softuni.exam.models.dto;

import softuni.exam.models.entity.enums.ApartmentType;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

@XmlAccessorType(XmlAccessType.FIELD)
public class ApartmentDto {

    @XmlElement(name = "apartment-type")
    private ApartmentType apartmentType;

    @XmlElement(name = "area")
    @Size(min = 40)
    private double area;

    @XmlElement(name = "town")
    private NameDto town;

    public ApartmentType getApartmentType() {
        return apartmentType;
    }

    public double getArea() {
        return area;
    }

    public NameDto getTown() {
        return town;
    }
}