package softuni.exam.models.dto;

public class AgentDto {
    public Object getTownName() {
    }

    public String getFirstName() {
    }
}
