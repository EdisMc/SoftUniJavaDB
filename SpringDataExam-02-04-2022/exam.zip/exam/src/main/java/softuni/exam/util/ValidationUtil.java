package softuni.exam.util;

public interface ValidationUtil {

    <T> boolean isValid(T entity);
}
